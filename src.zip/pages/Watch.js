const Watch = () => {
    return <h1>상세 페이지</h1>
}
export default Watch;